def power2(x):
    return x**2
def test_ans():
    assert power2(4) == 16