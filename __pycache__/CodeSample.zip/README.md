# Hmmimp
This is a crude from scratch implementation of HMM
